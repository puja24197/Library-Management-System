public class Main {
    public static void main(String[] args) {
        LibraryManager manager = new LibraryManager();

        try {
            // ১. আপনার Book ও Magazine ক্লাস দিয়ে অবজেক্ট তৈরি
            Book book = new Book(" ", 3, "Unknown author");
            Magazine magazine = new Magazine("Tech Today", 2, "IDG");

            // ২. CRUD - Create (যোগ করা)
            System.out.println("--- Adding Items ---");
            manager.addItem(book);
            manager.addItem(magazine);

            // ৩. CRUD - Read (প্রিন্ট করা)
            System.out.println("\n--- All Items in Library ---");
            manager.displayAllItems();

            // ৪. আপনার issueToStudent মেথড ব্যবহার করে Issue করা
            System.out.println("\n--- Issuing Book ---");
            manager.issueItem("Java Concepts", "ST2026", "student@univ.edu", 1);

        } catch (CustomException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}