 import java.util.ArrayList;
import java.util.List;

    public class LibraryManager {
        private List<LibraryItems> itemList;

        public LibraryManager() {
            // Load existing data from file on start
            this.itemList = FileManager.loadData();
        }

        // Create (Add Item)
        public void addItem(LibraryItems item) throws CustomException {
            if (item.getTitle() == null || item.getTitle().trim().isEmpty()) {
                throw new CustomException("Title cannot be empty!");
            }
            if (item.getTotalCopies() <= 0) {
                throw new CustomException("Total copies must be greater than 0!");
            }
            itemList.add(item);
            FileManager.saveData(itemList);
            System.out.println("Item added successfully!");
        }

        // Read (Display All Items)
        public void displayAllItems() {
            if (itemList.isEmpty()) {
                System.out.println("No items available in the library.");
                return;
            }
            for (LibraryItems item : itemList) {
                System.out.println(item.getDetails());
            }
        }

        // Update (Issue Item)
        public void issueItem(String title, String studentId, String email, int currentDate) throws CustomException {
            LibraryItems item = findItem(title);
            if (item == null) {
                throw new CustomException("Item not found: " + title);
            }
            if (!item.issueToStudent(studentId, email, currentDate)) {
                throw new CustomException("No copies available for issue!");
            }
            FileManager.saveData(itemList);
            System.out.println("Item issued successfully to " + studentId);
        }

        // Delete (Remove Item)
        public void deleteItem(String title) throws CustomException {
            LibraryItems item = findItem(title);
            if (item == null) {
                throw new CustomException("Cannot delete. Item not found!");
            }
            itemList.remove(item);
            FileManager.saveData(itemList);
            System.out.println("Item deleted successfully!");
        }

        // Helper method to search item by title
        public LibraryItems findItem(String title) {
            for (LibraryItems item : itemList) {
                if (item.getTitle().equalsIgnoreCase(title)) {
                    return item;
                }
            }
            return null;
        }
}
